java -Djava.library.path="lib" -d32 -jar NARD.jar
